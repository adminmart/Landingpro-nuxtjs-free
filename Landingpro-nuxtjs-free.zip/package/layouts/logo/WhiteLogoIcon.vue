<script setup lang="ts">
</script>
<template>
    <div class="logo">
      <NuxtLink to="/" class="">
        <img src="/images/logos/icon.svg" />
      </NuxtLink>
    </div>
  </template>
