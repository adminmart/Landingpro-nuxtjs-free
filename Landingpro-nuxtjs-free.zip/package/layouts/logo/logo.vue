<script setup lang="ts">
</script>
<template>
    <div class="logo">
      <NuxtLink to="/" >
        <img src="/images/logos/logo.svg" />
      </NuxtLink>
    </div>
  </template>
