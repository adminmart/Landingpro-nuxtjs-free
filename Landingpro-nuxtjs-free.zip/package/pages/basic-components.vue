<script setup lang="ts">
import Header from '@/layouts/header/Header.vue';
import MainBanner from '@/components/basic-components/MainBanner.vue';
import UiComponents from '@/components/basic-components/AllComponents.vue';
import UpgradetoPro from '@/components/custom-components/UpgradetoPro.vue';
import Footer from '@/layouts/footer/Footer.vue';
</script>
<template>
    <!--Header-->
    <Header />
    <MainBanner />
    <UiComponents />
    <UpgradetoPro />
    <Footer />
</template>

