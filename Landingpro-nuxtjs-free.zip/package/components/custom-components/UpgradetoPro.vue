<template>
    <div class="bg-primary py-sm-16 text-center">
      <v-container>
        <!-- -----------------------------------------------
              Start Coming Soon
          ----------------------------------------------- -->
        <v-row  class="d-flex align-center justify-center">
          <v-col cols="12" sm="6" md="6">
            <div>
              <h2 class="text-h2 text-white mb-3">
                Upgrade To Pro Version
              </h2>
              <h4 class=" text-white font-weight-light">
                We will add Pro Version with tons of great features and multiple
                category demos which is ready to use...
              </h4>
              <div class="mt-8">
                <v-btn
                    class="btn bg-white btn-custom-md"
                    to="/"
                    flat
                    size="large"
                >
                  upgrade
                </v-btn>
              </div>
            </div>
          </v-col>
        </v-row>
  
        <!-- -----------------------------------------------
              End Coming Soon
          ----------------------------------------------- -->
      </v-container>
    </div>
  </template>