<template>
    <div class="banner-wrapper bg-lightprimary d-flex align-center" style="min-height: 600px;">
      <v-container>
        <!-- -----------------------------------------------
              Start Banner
          ----------------------------------------------- -->
        <v-row justify="center">
          <v-col
            cols="12"
            sm="10"
            md="6"
            lg="7"
            class="d-flex align-center justify-center"
          >
            <div class="text-center">
              <h1 class="text-h1  mb-3">
                Landingpro nuxtjs kit
              </h1>
              <h4 class="text-h5  font-weight-regular ">
                Built with Nuxt Js and based on Vuetify js Free UI Kit
              </h4>
              <div class="mt-8">
                <v-btn to="/" size="large" color="primary" flat>
                  Upgrade to Pro
                </v-btn>
              </div>
            </div>
          </v-col>
        </v-row>
        <!-- -----------------------------------------------
              End Banner
          ----------------------------------------------- -->
      </v-container>
    </div>
  </template>
  