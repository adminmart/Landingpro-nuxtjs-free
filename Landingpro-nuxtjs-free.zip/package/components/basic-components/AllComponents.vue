<script setup lang="ts">
import { ref } from 'vue';
</script>
<template>
  <div>
    
    <!-----UI Button------->
    <BasicComponentsUiButton />
    <!-----UI Menu------->
    <BasicComponentsUiMenu />
    <!-----UI Chip------->
    <BasicComponentsUiChip />
    <!-----UI Chip------->
    <BasicComponentsUiPagination />
    <!-----UI Alert------->
    <BasicComponentsUiAlert />
    <!-----UI Card------->
    <BasicComponentsUiCard />
    <!-----UI Form------->
    <BasicComponentsUiForm />
    <!-----UI Table------->
    <BasicComponentsUiTable />
    <!-----UI Tooltip------->
    <BasicComponentsUiTooltip />
    <!----Typography------->
    <BasicComponentsUiTypography />

  </div>
</template>

