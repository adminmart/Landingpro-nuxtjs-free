<script setup lang="ts">
</script>
<template>
<v-locale-provider > 
  <v-app>
    <v-main>
      <!--Content-->
      <NuxtLayout>
        <NuxtPage />
      </NuxtLayout>
    </v-main>
  </v-app>
</v-locale-provider>
</template>